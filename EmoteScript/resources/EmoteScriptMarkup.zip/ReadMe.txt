EmoteScript.xml is for Notepad++.  It is used to show colors for the EmoteScript markup.  Looks better on a dark theme (like Dracula), but perfectly fine on a light theme too.   

To use:
Download EmoteScript.xml
Open Notepad++
Click Language->User Defined Language->Define your language
Then click the Import Button, and point to where you saved EmoteScript.xml and click Open (thats it).